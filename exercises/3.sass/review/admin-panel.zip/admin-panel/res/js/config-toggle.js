$(document).ready(function(){
    $(".config-toggle").click(function(){
        $("body").toggleClass("config-open");
    });
});