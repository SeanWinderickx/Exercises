$(document).ready(function(){
    $(".sub-menu-toggle").click(function(){
        $(this).toggleClass("sub-menu-open");
    });
});